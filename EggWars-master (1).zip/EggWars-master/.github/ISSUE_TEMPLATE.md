## Issue name

**Issue description**

- ...

**Server software:**

- PocketMine-MP 1.7dev-743 with API 3.0.0-ALPHA11

**Plugin version:**

- 1.0.0-beta1

**Steps to reproduce:**

1) ....
2) ....
3) ....


- [ ] Tested without other plugins
- [ ] There are not same issue